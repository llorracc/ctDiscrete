(* ::Package:: *)

If[NameQ["ParamsAreSet"]==True,If[ParamsAreSet==True,Print["This file should be executed before parameter values are defined."];Abort[]]];
<<Vars.m;
VerboseOutput=True;
<<Funcs.m;
