
This directory contains examples of how to use the code in "CoreCode"
to produce solutions to the Tractable buffer stock model.

DynanKohn contains software to generate figures for discussion of
paper by Karen Dynan and Donald Kohn "The Rise In U.S. Household
Indebtedness: Causes and Consequences" at the conference "The
Stability of the Financial System" at the Reserve Bank of Australia,
Sydney, August 2007

PalgravePrecautionary.nb generates the figure in 
"Precautionary Saving and Precautionary Wealth" with Miles Kimball for
Palgrave Dictionary of Economics and Finance, 2 nd Ed. 

http://www.econ2.jhu.edu/people/ccarroll/PalgravePrecautionary.pdf


TractableBufferStock.nb generates the figures for the handout
TractableBufferStock available on Christopher Carroll's web page.

uRise generates figures for an analysis of what happens in the wake of
an increase in the risk of unemployment.

