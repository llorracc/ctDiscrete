(* Parameter values for simulations *)

\[ScriptCapitalN] = 1.01;
