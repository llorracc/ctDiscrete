(* ::Package:: *)






(* Define the variables *)

(* \[Lambda] is the MPS for perfect foresight problem (like unemployed consumers); *)
(* \[Kappa]  is the MPC *)
\[Lambda]=((R)^-1) ((R) \[Beta])^(1/\[Rho]);
\[Kappa]=1-\[Lambda];

(* \[CapitalGamma] is the growth factor conditional on remaining employed *)
\[CapitalGamma]=\[GothicCapitalG]/(1-\[Mho]);

(* \[ScriptCapitalR] is the return factor for the normalized problem *)
(* (R) is the return factor in levels *)
\[ScriptCapitalR]=(R)/\[CapitalGamma];

(* \[CapitalThorn] is the growth patience factor *)
\[CapitalThorn]\[CapitalGamma]=((R) \[Beta])^(1/\[Rho])/\[CapitalGamma];
\[CapitalThorn]Rtn=((R) \[Beta])^(1/\[Rho])/(R);
\[WeierstrassP]\[Gamma]=Log[\[CapitalThorn]\[CapitalGamma]];
\[WeierstrassP]rtn=Log[\[CapitalThorn]];
\[CapitalPi]Alt=(1+(\[CapitalThorn]\[CapitalGamma]^-\[Rho]-1)/\[Mho])^(1/\[Rho]);
\[GothicH]=(1/(1-\[GothicCapitalG]/(R)));  (* Human wealth *)
\[Zeta]=\[ScriptCapitalR] \[Kappa] \[CapitalPi]Alt; (* A useful constant *)
\[Beta] = 1/(1+\[CurlyTheta]); (* Time preference factor *)
(R)= 1+rrr;
\[GothicCapitalG]= 1+\[GothicG];

(* Target values of \[ScriptM],\[ScriptC],\[ScriptA],\[ScriptB]E,\[ScriptB]U,\[ScriptC]U *)
\[ScriptM]E=1+((R)/(\[CapitalGamma]+\[Zeta] \[CapitalGamma]-(R)));
\[ScriptC]E=(1-\[ScriptCapitalR]^-1)\[ScriptM]E+\[ScriptCapitalR]^-1;
\[ScriptA]E=\[ScriptM]E-\[ScriptC]E;
\[ScriptB]E=\[ScriptA]E \[ScriptCapitalR];
\[ScriptY]E=\[ScriptA]E (\[ScriptCapitalR]-1) + 1;
\[ScriptX]E=Chop[\[ScriptY]E -\[ScriptC]E];
\[ScriptB]U=\[ScriptB]E;
\[ScriptM]U=\[ScriptM]E;
\[ScriptC]U=\[ScriptM]U \[Kappa];
\[GothicV] =1/(1-\[Beta] (((R) \[Beta])^((1/\[Rho])-1)));
\[ScriptV]U=u[\[ScriptC]U] \[GothicV];
\[ScriptV]E=(u[\[ScriptC]E] + \[Beta] (\[CapitalGamma]^(1-\[Rho])) \[Mho] vUPF[\[ScriptA]E \[ScriptCapitalR]])/(1-\[Beta] (\[CapitalGamma]^(1-\[Rho]) (1-\[Mho])));
                                                                                                                                                   
(* Combined discount factor for normalized problem *)                                                                                              
\[Bet] = \[ScriptCapitalR] \[Beta] \[CapitalGamma]^(1-\[Rho]);

(* Find MPC at steady state *)
\[Natural]EFunc[\[Kappa]Etp1_] := \[Bet] \[ScriptCapitalR] ((1-\[Mho]) \[Kappa]Etp1 + \[Mho] (\[Kappa] \[ScriptA]E \[ScriptCapitalR]/\[ScriptC]E)^(-\[Rho]-1) \[Kappa]);
\[Kappa]EFind := \[Kappa]ESeek /. FindInstance[ \[Kappa]ESeek (1+\[Natural]EFunc[\[Kappa]ESeek]) == \[Natural]EFunc[\[Kappa]ESeek] && 0 < \[Kappa]ESeek < 1,\[Kappa]ESeek][[1]];

(* Find limiting MPC as m approaches zero *)
\[Natural]EFuncLim0[\[Kappa]Et_] := \[Bet] \[ScriptCapitalR] \[Mho] (\[Kappa] \[ScriptCapitalR] ((1-\[Kappa]Et)/\[Kappa]Et))^(-\[Rho]-1) \[Kappa];
\[Kappa]Lim0Find := \[Kappa]ESeek /.  FindRoot[ \[Kappa]ESeek == \[Natural]EFuncLim0[\[Kappa]ESeek]/(1 + \[Natural]EFuncLim0[\[Kappa]ESeek]), {\[Kappa]ESeek, 0.5, \[Lambda]}];

(* Analytical formula for \[Kappa] prime at target *)
\[DoubleStruckCapitalE]uPPP\[Kappa]Squared = (1-\[Mho]) u'''[\[ScriptC]E] \[Kappa]E^2 + \[Mho] u'''[\[Kappa] \[ScriptA]E \[ScriptCapitalR]] \[Kappa]^2;
\[DoubleStruckCapitalE]uPP\[Kappa]    = (1-\[Mho])  u''[\[ScriptC]E] \[Kappa]E   + \[Mho] u''[ \[Kappa] \[ScriptA]E \[ScriptCapitalR]] \[Kappa]  ;
\[Kappa]EP = (\[Bet] \[ScriptCapitalR]^2 (1-\[Kappa]E)^2 \[DoubleStruckCapitalE]uPPP\[Kappa]Squared-u'''[\[ScriptC]E] \[Kappa]E^2 )/
  (u''[\[ScriptC]E] + \[Bet] \[ScriptCapitalR] \[DoubleStruckCapitalE]uPP\[Kappa]-\[Bet] \[ScriptCapitalR]^2 (1-\[Kappa]E)^2 (1-\[Mho]) u''[\[ScriptC]E]);

CheckFor\[CapitalGamma]Impatience  :=If[\[CapitalThorn]\[CapitalGamma]>= 1.,Print["Aborting: Employed Consumer Not Growth Impatient."];Abort[]];
CheckForRImpatience:=If[\[CapitalThorn]Rtn>= 1.,Print["Aborting: Employed Consumer Not Return Impatient."];Abort[]];

(* Now define the functions used in solving the model *)

(* Define utility function from highest to lowest derivative to avoid Mathematica difficulties *)
Clear[u];
u'''[c_] := -\[Rho](-\[Rho]-1) c^(-\[Rho]-2);
u''[c_] := -\[Rho] c^(-\[Rho]-1);
u'[c_] := c^-\[Rho];
u[c_] := If[ Chop[\[Rho]-1] != 0, (c^(1-\[Rho]))/(1-\[Rho]), Log[c] ];

cE[m_] := \[ScriptC]Interp[m];

cEPF[\[ScriptM]_] := (\[ScriptM]-1+\[GothicH])\[Kappa];
vEPF[\[ScriptM]_] := u[ cEPF[\[ScriptM]]] \[GothicV]+If[ Chop[\[Rho]-1] == 0, Log[ (R) \[Beta] ] (\[Beta]/((\[Beta]-1)^2)),0];
cUPF[\[ScriptM]_]  := \[Kappa] \[ScriptM];
vUPF[\[ScriptM]_]  := u[ \[Kappa] \[ScriptM] ] \[GothicV]+If[ Chop[\[Rho]-1] == 0, Log[ (R) \[Beta] ] (\[Beta]/((\[Beta]-1)^2)),0];
\[ScriptC]EDelEqZero[\[ScriptM]_] := ((\[ScriptCapitalR] \[Kappa] \[CapitalPi]Alt)/(1+\[ScriptCapitalR] \[Kappa] \[CapitalPi]Alt))\[ScriptM];
\[ScriptM]EDelEqZero[\[ScriptM]_] := (\[CapitalGamma]/(R))+(1-\[CapitalGamma]/(R))\[ScriptM];
\[ScriptM]Etp1Fromt[\[ScriptM]Et_,\[ScriptC]Et_] := (\[ScriptM]Et-\[ScriptC]Et)\[ScriptCapitalR]+1.;
\[ScriptC]EtFromtp1[\[ScriptM]Etp1_,\[ScriptC]Etp1_] := \[CapitalGamma] ((R) \[Beta])^(-1/\[Rho]) \[ScriptC]Etp1  (1+ \[Mho] ((\[ScriptC]Etp1/(\[Kappa] (\[ScriptM]Etp1-1)))^\[Rho]-1))^(-1/\[Rho]);
\[ScriptM]EtFromtp1[\[ScriptM]Etp1_,\[ScriptC]Etp1_] := (\[CapitalGamma]/(R))(\[ScriptM]Etp1-1)+ \[ScriptC]EtFromtp1[\[ScriptM]Etp1,\[ScriptC]Etp1];
\[Kappa]EtFromtp1[\[ScriptM]Etp1_,\[ScriptC]Etp1_,\[Kappa]Etp1_,\[ScriptM]Et_,\[ScriptC]Et_] := Block[{},
  \[ScriptC]Utp1 = \[Kappa] (\[ScriptM]Et-\[ScriptC]Et) \[ScriptCapitalR];
  \[Natural] =  \[Bet] \[ScriptCapitalR] (1/u''[\[ScriptC]Et]) ((1-\[Mho]) u''[\[ScriptC]Etp1] \[Kappa]Etp1 + \[Mho] u''[\[ScriptC]Utp1] \[Kappa]);
  Return[\[Natural]/(1+\[Natural])]
];
cETaylorNearTarget[\[FilledUpTriangle]_] := \[ScriptC]E+\[FilledUpTriangle] \[Kappa]E +(1/2) (\[FilledUpTriangle]^2)\[Kappa]EP;
vE'[\[ScriptM]_] := u'[\[ScriptC]Interp[\[ScriptM]]] /; \[ScriptM] <= \[ScriptM]Bottp1; (* Use consumption function *)
vE'[\[ScriptM]_] := \[ScriptV]Interp'[\[ScriptM] ] /; \[ScriptM] > \[ScriptM]Bottp1; (* Use interpolating approximation *)

vE[\[ScriptM]_] := \[ScriptV]Bottp1 + NIntegrate[u'[\[ScriptC]Interp[\[ScriptM]\[Bullet]]],{\[ScriptM]\[Bullet],\[ScriptM]Bottp1, \[ScriptM]}] /; \[ScriptM] <= \[ScriptM]Bottp1; (* If \[ScriptM] is below the bottom, use consumption function to construct \[ScriptV] *)
vE[\[ScriptM]_] := \[ScriptV]Interp[\[ScriptM]] /; \[ScriptM] > \[ScriptM]Bottp1; (* Otherwise use interpolating approximation *)



(* Define a function which iterates the reverse Euler equations until it reaches *)
(* a point outside some predefined boundaries *)

BackShoot[InitialPoints_] := Block[{\[ScriptM]Prev,\[ScriptC]Prev,\[Kappa]Prev,\[ScriptV]Prev,\[ScriptM]MaxBound=100000,\[ScriptM]MinBound=1/\[ScriptM]E,Counter = 0,PointsList =InitialPoints},
{\[ScriptM]Prev,\[ScriptC]Prev,\[Kappa]Prev,\[ScriptV]Prev} = Take[InitialPoints[[-1]],4];
If[VerboseOutput != False, Print["Solving ..."]];
While[
  \[ScriptM]Prev > \[ScriptM]MinBound \[ScriptM]E && \[ScriptM]Prev <= \[ScriptM]MaxBound \[ScriptM]E,
    AppendTo[
        PointsList
          ,{\[ScriptM]Now,\[ScriptC]Now} = {\[ScriptM]EtFromtp1[\[ScriptM]Prev,\[ScriptC]Prev],\[ScriptC]EtFromtp1[\[ScriptM]Prev,\[ScriptC]Prev]};
          \[Kappa]Now = \[Kappa]EtFromtp1[\[ScriptM]Prev,\[ScriptC]Prev,\[Kappa]Prev,\[ScriptM]Now,\[ScriptC]Now];
          \[ScriptV]Now = u[\[ScriptC]Now] + \[Beta] (\[CapitalGamma]^(1-\[Rho])) ((1-\[Mho]) \[ScriptV]Prev + \[Mho] vUPF[(\[ScriptM]Now-\[ScriptC]Now)\[ScriptCapitalR] ]);
          {\[ScriptM]Prev,\[ScriptC]Prev,\[Kappa]Prev,\[ScriptV]Prev} = {\[ScriptM]Now,\[ScriptC]Now,\[Kappa]Now,\[ScriptV]Now}
    ];
    If[\[ScriptM]Prev<=\[ScriptM]MinBound  \[ScriptM]E && VerboseOutput != False,Print["  Below \[ScriptM]MinBound times \[ScriptM]E after ",Counter," backwards Euler iterations."]];
    If[\[ScriptM]Prev > \[ScriptM]MaxBound \[ScriptM]E && VerboseOutput != False,Print["  Above \[ScriptM]MaxBound times \[ScriptM]E after ",Counter," backwards Euler iterations."]];
  Counter++];
Return[PointsList]
];


EulerPointsStartingFromSSPlus[\[FilledUpTriangle]_] := Block[{},
  \[ScriptM]Start = \[ScriptM]E + \[FilledUpTriangle];
  \[Kappa]Start   = \[Kappa]E   + \[Kappa]EP \[FilledUpTriangle];
  \[ScriptC]Start = cETaylorNearTarget[\[FilledUpTriangle]];
  \[ScriptV]Start = \[ScriptV]E + NIntegrate[u'[cETaylorNearTarget[\[Bullet]]],{\[Bullet],0,\[FilledUpTriangle]}];
  StartPoint = {\[ScriptM]Start,\[ScriptC]Start,\[Kappa]Start,\[ScriptV]Start};
  BackShoot[{StartPoint}]
];

FindStableArm := Block[{},
  \[Kappa]E    = \[Kappa]EFind;
  \[Kappa]EMax = \[Kappa]Lim0Find;
  StableArmBelowSS = Sort[EulerPointsStartingFromSSPlus[-\[CurlyEpsilon] ]];
  StableArmAboveSS = EulerPointsStartingFromSSPlus[\[CurlyEpsilon]];  (* No precision augmentation necessary for upper arm *)
  {\[ScriptM]Bot,\[ScriptC]Bot,\[Kappa]Bot,\[ScriptV]Bot} = Take[StableArmBelowSS[[ 1]],4];
  {\[ScriptM]Bottp1,\[ScriptC]Bottp1,\[Kappa]Bottp1,\[ScriptV]Bottp1} = Take[StableArmBelowSS[[ 2]],4];
  {\[ScriptM]Top,\[ScriptC]Top,\[Kappa]Top,\[ScriptV]Top} = Take[StableArmAboveSS[[-1]],4];
  ETarget = {\[ScriptM]E,\[ScriptC]E,\[Kappa]E,\[ScriptV]E};
  StableArmPoints = Sort[Union[Join[StableArmBelowSS,{ETarget},StableArmAboveSS]]];
  {\[ScriptM]Vec,\[ScriptC]Vec,\[Kappa]Vec,\[ScriptV]Vec} = Take[Transpose[StableArmPoints],4];
uPVec   = u'[\[ScriptC]Vec];
uPPVec  = u''[\[ScriptC]Vec];
uPPPVec = u'''[\[ScriptC]Vec];
\[ScriptV]PVec   = uPVec;
\[ScriptV]PPVec  = uPPVec \[Kappa]Vec;

\[ScriptC]Interp = Interpolation[
  Join[
    {{0.,{0.,\[Kappa]EMax}}}
   ,Transpose[{\[ScriptM]Vec,Transpose[{\[ScriptC]Vec,\[Kappa]Vec}]}]
   ,{{\[ScriptM]Vec[[-1]]+(\[ScriptM]Vec[[-1]]-\[ScriptM]Vec[[-2]]),{\[ScriptC]Vec[[-1]]+(\[ScriptM]Vec[[-1]]-\[ScriptM]Vec[[-2]]) \[Kappa]Vec[[-1]],\[Kappa]Vec[[-1]]}}}
  ]
];
];

SimAddAnotherPoint[\[ScriptM]\[ScriptC]Path_]:= Block[{},
  \[ScriptM]NextVal = \[ScriptM]Etp1Fromt[\[ScriptM]\[ScriptC]Path[[-1,1]],\[ScriptM]\[ScriptC]Path[[-1,2]]];
  \[ScriptC]NextVal = \[ScriptC]Interp[\[ScriptM]NextVal];
  {\[ScriptM]NextVal,\[ScriptC]NextVal}];

SimGeneratePath[\[ScriptM]Initial_,PeriodsToGo_] := Block[{},
  \[ScriptC]Initial = \[ScriptC]Interp[\[ScriptM]Initial];
  \[ScriptM]\[ScriptC]Path = {{\[ScriptM]EBase,\[ScriptC]EBase},{\[ScriptM]Initial,\[ScriptC]Initial}};
  Do[AppendTo[\[ScriptM]\[ScriptC]Path,SimAddAnotherPoint[\[ScriptM]\[ScriptC]Path]],{PeriodsToGo}];
];

(* Miscellaneous other useful functions *)

\[ScriptCapitalC]tp1O\[ScriptCapitalC]t[\[ScriptM]_] := (((R) \[Beta])^(1/\[Rho]) (1+\[Mho] (\[ScriptC]Interp[(\[ScriptM]-\[ScriptC]Interp[\[ScriptM]])\[ScriptCapitalR]+1]/(\[Kappa] (\[ScriptM]-\[ScriptC]Interp[\[ScriptM]])\[ScriptCapitalR])-1))^(1/\[Rho]));

ShowParams:=MatrixForm[Map[{#,ToExpression[#]}&,{"\[Mho]","\[Rho]","\[Kappa]E","\[Kappa]","\[CapitalGamma]","\[ScriptCapitalR]","\[CapitalThorn]\[CapitalGamma]","\[CapitalThorn]","\[WeierstrassP]\[Gamma]","\[WeierstrassP]rtn","\[CapitalPi]Alt","\[GothicH]","\[Zeta]","\[Beta] ","(R)","\[GothicCapitalG]","rrr","\[CurlyTheta]","\[GothicG]","\[ScriptM]E","\[ScriptC]E","\[CurlyEpsilon]"}]];

SteadyStateVals= { \[ScriptB]E, \[ScriptM]E, \[ScriptC]E, \[ScriptA]E, \[Kappa]E, \[ScriptV]E};

