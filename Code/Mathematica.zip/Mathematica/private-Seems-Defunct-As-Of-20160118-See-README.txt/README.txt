The files contained herein seem to reflect an earlier mechanism for making private vs public
versions of the code.  These mechanisms have apparently been superceded by the automatic
shell scripts that make Pub and Pri versions of code more generally.

CDC, 2016-01-18

