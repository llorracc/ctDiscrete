#!/bin/sh

source /etc/profile
source ~/.profile

ShellLaunchDir=${0%/*}

cd $ShellLaunchDir

cd ..

echo `pwd`

math < TractableBufferStock.m > private/TractableBufferStock.out

