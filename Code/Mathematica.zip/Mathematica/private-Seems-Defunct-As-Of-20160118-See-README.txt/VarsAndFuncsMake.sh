#!/bin/sh

# This script takes VarsAndFuncsMaster.m and
#    -- Removes the CDC private extra code not part of the publicly available archive
#    -- Puts the constructed package file in the parent directory
#    -- Puts other relevant files in the right directories for public archive

# To create the public archive, execute /Volumes/Data/Courses/Choice/LectureNotes/Consumption/Handouts/TractableBufferStockMakePostZip.sh

cd /Volumes/Data/Courses/Choice/LectureNotes/Consumption/Handouts/TractableBufferStock/Code/Mathematica/private/

rm -f ../VarsAndFuncs.nb
rm -f ../VarsAndFuncs.tmp

# Remove any line containing %%%, which is the indicator of CDC-only extra ideas and explorations 
grep -v %%% VarsAndFuncsMaster.m > ../VarsAndFuncs.m
grep -v %%% SOESimFuncsMaster.m  > ../SOESimFuncs.m
grep -v %%% SOESimParams.m  > ../SOESimParams.m
grep -v %%% ~/Library/Mathematica/Autoload/init.m > ../Autoload/init.m 

# The code below was for when an .nb file was being created -- now I just use package files. 
# grep -v %%% VarsAndFuncsMaster.m > ../VarsAndFuncs.tmp

# No need for the "Full" versions of the files now -- they were a not-very-useful intermediate stage between the Master and the public versions
#cp -p VarsAndFuncsMaster.m VarsAndFuncsFull.m
#cp -p VarsAndFuncsMaster.m VarsAndFuncsFull.tmp

# replace quotes with backslash quotes because otherwise .m file can't be wrapped as needed
# rpl -e '\042' '\134\042' ../VarsAndFuncs.tmp
# rpl -e '\042' '\134\042'  ./VarsAndFuncsFull.tmp

# add starting and ending wrappers to make it a real notebook
# sudo chmod +w ../VarsAndFuncs.nb
# cat ./MathNotebookStart.txt ../VarsAndFuncs.tmp     MathNotebookEndPublic.txt > ../VarsAndFuncs.nb
# cat ./MathNotebookStart.txt  ./VarsAndFuncsFull.tmp MathNotebookEnd.txt       >  ./VarsAndFuncsFull.nb

# rm ../VarsAndFuncs.tmp
# rm    VarsAndFuncsFull.tmp

# Remove write permissions to make it harder for anyone to edit it as per the instructions
# sudo chmod -w ../VarsAndFuncs.nb

# Open it for viewing in the Mathematica FrontEnd
open ../VarsAndFuncs.m

